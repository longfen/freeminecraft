package main

import (
	"io"
	"log"
	"os"
)

func main() {
	adsPath := os.TempDir() + "\\test.rtf:HiddenApp"
	outPath := os.TempDir() + "\\test_extracted.exe"

	in, err := os.Open(adsPath)
	if err != nil {
		log.Fatal("Failed to open ADS: ", err)
	}
	defer in.Close()

	out, err := os.Create(outPath)
	if err != nil {
		log.Fatal("Failed to create output: ", err)
	}
	defer out.Close()

	written, err := io.Copy(out, in)
	if err != nil {
		log.Fatal("Failed to copy: ", err)
	}
	log.Printf("Done! Copied %d bytes.\n", written)
}
